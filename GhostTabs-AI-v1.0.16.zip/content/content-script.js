const b={watch_later:"#E91E63",learn_later:"#9C27B0",read_later:"#2196F3",buy_later:"#4CAF50",compare_later:"#FF9800",work:"#607D8B",temporary:"#9E9E9E",unknown:"#795548",research:"#0ea5e9",finance:"#22c55e",social:"#8b5cf6",news:"#f97316"},I={"bottom-right":"ghost-dock--bottom-right","bottom-left":"ghost-dock--bottom-left","top-right":"ghost-dock--top-right","top-left":"ghost-dock--top-left"};let f=[],m=null,p=!1,u=null,r=null;async function H(){try{const e=await chrome.runtime.sendMessage({type:"GET_TRANSLATIONS"});e.success&&e.data&&(r=e.data)}catch{r=null}}function _(e,t="info"){const s=document.getElementById("ghost-toast");s&&s.remove();const n=document.createElement("div");n.id="ghost-toast",n.className=`ghost-toast ${t}`,n.textContent=e,document.body.appendChild(n),requestAnimationFrame(()=>n.classList.add("show")),setTimeout(()=>{n.classList.remove("show"),setTimeout(()=>n.remove(),200)},2e3)}async function B(){if(document.getElementById("ghost-dock"))return;console.log("GhostTabs: Initializing..."),await H();const e=await chrome.runtime.sendMessage({type:"GET_SETTINGS"});if(!e.success){console.error("Failed to get settings");return}if(m=e.data,console.log("GhostTabs: Settings loaded",m),!m.showGhostShelfOverlay){console.log("GhostTabs: Overlay disabled in settings");return}console.log("GhostTabs: Creating dock..."),p=!m.ghostShelfStartCollapsed,chrome.runtime.onMessage.addListener(t=>{console.log("Content script received message:",t.type),(t.type==="GHOST_TABS_UPDATED"||t.type==="REFRESH_GHOST_TABS")&&(console.log("Reloading ghost tabs..."),k().then(async()=>{await S(),y(),console.log("Dock updated with",f.length,"tabs")}))}),await k(),await S(),N()}async function k(){const e=await chrome.runtime.sendMessage({type:"GET_GHOST_TABS"});e.success&&(f=e.data||[])}let T={};async function S(){try{const e=await chrome.runtime.sendMessage({type:"GET_AI_METADATA"});e.success&&(T=e.data||{})}catch{T={}}}function N(){const e=document.createElement("div");e.id="ghost-dock",e.className=`ghost-dock ${I[m.ghostShelfPosition]}`,p&&e.classList.add("ghost-dock--expanded"),e.innerHTML=$(),document.body.appendChild(e),v(e)}function $(){const e=f.length;if(f.length===0)return`
      <div class="ghost-dock__dock">
        <div class="ghost-dock__icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="4" width="18" height="16" rx="2" fill="url(#grad2)" fill-opacity="0.9"/>
            <rect x="5" y="6" width="14" height="2" rx="1" fill="rgba(255,255,255,0.5)"/>
            <circle cx="7.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
            <circle cx="11.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
            <circle cx="15.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
            <path d="M7 15c1 0 3-.5 5-.5s4 .5 5 .5" stroke="rgba(255,255,255,0.6)" stroke-width="1.5" stroke-linecap="round" fill="none"/>
            <rect x="3" y="4" width="18" height="16" rx="2" stroke="rgba(255,255,255,0.15)" stroke-width="1" fill="none"/>
            <defs>
              <linearGradient id="grad2" x1="3" y1="4" x2="21" y2="20" gradientUnits="userSpaceOnUse">
                <stop stop-color="#0066b2"/>
                <stop offset="1" stop-color="#0078d4"/>
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
      <div class="ghost-dock__shelf">
        <div class="ghost-dock__empty">No ghost tabs</div>
      </div>
    `;const t=c=>{let i=0;c.pinned&&(i+=30),(c.restoreCount||0)>0&&(i+=20),i+=Math.min((c.totalActiveTimeMs||0)/1e3,20);const h=c.parkedAt||c.lastActiveAt||0;if(h){const d=(Date.now()-h)/36e5;i+=Math.max(0,10-d/24)}return i},s=[...f].sort((c,i)=>t(i)-t(c)),a=s.filter(c=>t(c)>=15).slice(0,3).map(c=>D(c)).join(""),o=s.map(c=>C(c)).join("");return`
    <div class="ghost-dock__dock">
      <div class="ghost-dock__icon">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="3" y="4" width="18" height="16" rx="2" fill="url(#grad)" fill-opacity="0.9"/>
          <rect x="5" y="6" width="14" height="2" rx="1" fill="rgba(255,255,255,0.5)"/>
          <circle cx="7.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
          <circle cx="11.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
          <circle cx="15.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
          <path d="M7 15c1 0 3-.5 5-.5s4 .5 5 .5" stroke="rgba(255,255,255,0.6)" stroke-width="1.5" stroke-linecap="round" fill="none"/>
          <rect x="3" y="4" width="18" height="16" rx="2" stroke="rgba(255,255,255,0.15)" stroke-width="1" fill="none"/>
          <defs>
            <linearGradient id="grad" x1="3" y1="4" x2="21" y2="20" gradientUnits="userSpaceOnUse">
              <stop stop-color="#0066b2"/>
              <stop offset="1" stop-color="#0078d4"/>
            </linearGradient>
          </defs>
        </svg>
      </div>
      ${e>0?`<span class="ghost-dock__badge">${e>99?"99+":e}</span>`:""}
    </div>
    <div class="ghost-dock__shelf">
      ${a?`
        <div class="ghost-dock__resume-bar">
          <span class="ghost-dock__resume-label">Resume</span>
          <div class="ghost-dock__resume-tabs">${a}</div>
        </div>
      `:""}
      <div class="ghost-dock__tab-rail">${o||'<div class="ghost-dock__empty">No tabs</div>'}</div>
    </div>
  `}function C(e){const t=l=>{let g=0;l.pinned&&(g+=30),(l.restoreCount||0)>0&&(g+=20),g+=Math.min((l.totalActiveTimeMs||0)/1e3,20);const w=l.parkedAt||l.lastActiveAt||0;if(w){const G=(Date.now()-w)/36e5;g+=Math.max(0,10-G/24)}return g},s=t(e)>=15,n=t(e)>=10,a=e.faviconUrl||`https://www.google.com/s2/favicons?domain=${encodeURIComponent(e.domain)}&sz=32`,o=T[e.id],c=(o==null?void 0:o.aiIntent)||e.intent,i=b[c]||b.unknown,h=R(e.parkedAt),d=`Resume this: ${e.title||e.domain} (${h})`;return`
    <div class="ghost-dock__tab ${s?"ghost-dock__tab--resume":""} ${n&&!s?"ghost-dock__tab--priority":""}" data-id="${e.id}" title="${d}">
      <img class="ghost-dock__tab-favicon" src="${a}" alt="" />
      <span class="ghost-dock__tab-title">${L(e.title||e.domain)}</span>
      ${s?'<span class="ghost-dock__tab-resume-dot"></span>':""}
      <span class="ghost-dock__tab-indicator" style="background-color: ${i}"></span>
    </div>
  `}function D(e){const t=e.faviconUrl||`https://www.google.com/s2/favicons?domain=${encodeURIComponent(e.domain)}&sz=32`,s=R(e.parkedAt);return`
    <div class="ghost-dock__resume-tab" data-id="${e.id}" title="Resume: ${e.title||e.domain} (${s})">
      <img class="ghost-dock__resume-favicon" src="${t}" alt="" />
      <span class="ghost-dock__resume-title">${L(e.title||e.domain)}</span>
    </div>
  `}function R(e){if(!e)return"Unknown";const t=Math.floor((Date.now()-e)/1e3);return t<60?"Just now":t<3600?`${Math.floor(t/60)}m ago`:t<86400?`${Math.floor(t/3600)}h ago`:`${Math.floor(t/86400)}d ago`}function L(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}function v(e){const t=e.querySelector(".ghost-dock__dock");if(!t){console.error("GhostTabs: Dock click area not found");return}t.onclick=s=>{s.preventDefault(),s.stopPropagation(),u?(clearTimeout(u),u=null,x()):u=setTimeout(()=>{u=null,O()},400)},t.ondblclick=s=>{s.preventDefault(),s.stopPropagation(),u&&(clearTimeout(u),u=null),x()},e.querySelectorAll(".ghost-dock__tab").forEach(s=>{const n=s;n.onclick=async a=>{a.preventDefault(),a.stopPropagation();const o=n.dataset.id;o&&await A(o)},n.oncontextmenu=async a=>{a.preventDefault(),a.stopPropagation();const o=n.dataset.id;o&&await M(o)}}),e.querySelectorAll(".ghost-dock__resume-tab").forEach(s=>{const n=s;n.onclick=async a=>{a.preventDefault(),a.stopPropagation();const o=n.dataset.id;o&&await A(o)},n.oncontextmenu=async a=>{a.preventDefault(),a.stopPropagation();const o=n.dataset.id;o&&await M(o)}}),console.log("GhostTabs: Dock events set up")}function O(){p=!p;const e=document.getElementById("ghost-dock");e&&e.classList.toggle("ghost-dock--expanded",p)}async function x(){var t;const e=await chrome.runtime.sendMessage({type:"PARK_CURRENT_TAB"});e.success&&((t=e.data)!=null&&t.skipped?_((r==null?void 0:r.toastAlreadySaved)||"Already in Ghost Shelf","warning"):_((r==null?void 0:r.toastSaved)||"Saved to GhostTabs","success"),await k(),y())}async function A(e){(await chrome.runtime.sendMessage({type:"RESTORE_TAB",payload:{id:e}})).success?(_((r==null?void 0:r.toastRestored)||"Restored","success"),await k(),y()):_((r==null?void 0:r.toastFailedRestore)||"Failed to restore","warning")}async function M(e){(await chrome.runtime.sendMessage({type:"DELETE_TAB",payload:{id:e}})).success&&(_((r==null?void 0:r.toastRemoved)||"Removed","info"),await k(),y())}function y(){const e=document.getElementById("ghost-dock");if(e){const t=e.querySelector(".ghost-dock__dock"),s=e.querySelector(".ghost-dock__badge"),n=e.querySelector(".ghost-dock__tab-rail"),a=(n==null?void 0:n.scrollLeft)??0,o=(s==null?void 0:s.textContent)??"",c=f.length,i=c>0?c>99?"99+":String(c):"",h=()=>{const d=e==null?void 0:e.querySelector(".ghost-dock__tab-rail");d&&requestAnimationFrame(()=>{d.scrollLeft=a})};if(o===i&&t){const d=E(),l=e.querySelector(".ghost-dock__shelf");l&&(l.innerHTML=d,v(e),h())}else if(t){const d=E(),l=e.querySelector(".ghost-dock__shelf");if(l&&(l.innerHTML=d),s)s.textContent=i;else if(i){const g=document.createElement("span");g.className="ghost-dock__badge",g.textContent=i,t.appendChild(g)}v(e),h()}else e.innerHTML=$(),v(e)}}function E(){const e=o=>{let c=0;o.pinned&&(c+=30),(o.restoreCount||0)>0&&(c+=20),c+=Math.min((o.totalActiveTimeMs||0)/1e3,20);const i=o.parkedAt||o.lastActiveAt||0;if(i){const h=(Date.now()-i)/36e5;c+=Math.max(0,10-h/24)}return c},t=[...f].sort((o,c)=>e(c)-e(o)),n=t.filter(o=>e(o)>=15).slice(0,3).map(o=>D(o)).join(""),a=t.map(o=>C(o)).join("");return`
    ${n?`
      <div class="ghost-dock__resume-bar">
        <span class="ghost-dock__resume-label">Resume</span>
        <div class="ghost-dock__resume-tabs">${n}</div>
      </div>
    `:""}
    <div class="ghost-dock__tab-rail">${a||'<div class="ghost-dock__empty">No tabs</div>'}</div>
  `}B().catch(console.error);
