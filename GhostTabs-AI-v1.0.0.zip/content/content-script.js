const C={watch_later:"#E91E63",learn_later:"#9C27B0",read_later:"#2196F3",buy_later:"#4CAF50",compare_later:"#FF9800",work:"#607D8B",temporary:"#9E9E9E",unknown:"#795548",research:"#0ea5e9",finance:"#22c55e",social:"#8b5cf6",news:"#f97316"},B={"bottom-right":"ghost-dock--bottom-right","bottom-left":"ghost-dock--bottom-left","top-right":"ghost-dock--top-right","top-left":"ghost-dock--top-left"};let f=[],w=null,p=!1,u=null,v=[],l=null,m="",g=null;async function L(){try{const t=await chrome.runtime.sendMessage({type:"GET_TRANSLATIONS"});t.success&&t.data&&(l=t.data)}catch{l=null}}function T(t,e="info"){const s=document.getElementById("ghost-toast");s&&s.remove();const o=document.createElement("div");o.id="ghost-toast",o.className=`ghost-toast ${e}`,o.textContent=t,document.body.appendChild(o),requestAnimationFrame(()=>o.classList.add("show")),setTimeout(()=>{o.classList.remove("show"),setTimeout(()=>o.remove(),200)},2e3)}async function F(){if(document.getElementById("ghost-dock"))return;console.log("GhostTabs: Initializing..."),await L();const t=await chrome.runtime.sendMessage({type:"GET_SETTINGS"});if(!t.success){console.error("Failed to get settings");return}if(w=t.data,console.log("GhostTabs: Settings loaded",w),!w.showGhostShelfOverlay){console.log("GhostTabs: Overlay disabled in settings");return}console.log("GhostTabs: Creating dock..."),p=!w.ghostShelfStartCollapsed,chrome.runtime.onMessage.addListener(e=>{console.log("Content script received message:",e.type),(e.type==="GHOST_TABS_UPDATED"||e.type==="REFRESH_GHOST_TABS")&&(console.log("Reloading ghost tabs..."),_().then(s=>{$().then(()=>{const o=document.getElementById("ghost-dock");o&&s&&(o.innerHTML=S(),A(o),console.log("Dock updated with",f.length,"tabs"))})}))}),await _(),await $(),H(),document.addEventListener("keydown",e=>{if(e.key==="/"&&!["INPUT","TEXTAREA"].includes(e.target.tagName)){e.preventDefault();const s=document.querySelector(".ghost-dock__search-input");if(s){s.focus(),p=!0;const o=document.getElementById("ghost-dock");o&&o.classList.add("ghost-dock--expanded")}}if(e.key==="Escape"){const s=document.querySelector(".ghost-dock__search-input");document.activeElement===s&&(s.blur(),m="")}}),setInterval(async()=>{await L();const e=await _();await $();const s=document.getElementById("ghost-dock");s&&e&&(s.innerHTML=S(),A(s))},5e3)}async function _(){const t=await chrome.runtime.sendMessage({type:"GET_GHOST_TABS"});if(t.success){const e=t.data||[],s=e.map(a=>a.id).sort(),o=v.slice().sort(),c=s.length>v.length||s.some(a=>!v.includes(a)),n=v.some(a=>!s.includes(a));return c||n||s.length!==o.length?(v=e.map(a=>a.id),f=e,!0):(f=e,!1)}return!1}let E={};async function $(){try{const t=await chrome.runtime.sendMessage({type:"GET_AI_METADATA"});t.success&&(E=t.data||{})}catch{E={}}}function H(){const t=document.createElement("div");t.id="ghost-dock",t.className=`ghost-dock ${B[w.ghostShelfPosition]}`,p&&t.classList.add("ghost-dock--expanded"),t.innerHTML=S(),document.body.appendChild(t),A(t)}function S(){const t=f.length;if(f.length===0)return`
      <div class="ghost-dock__dock">
        <div class="ghost-dock__icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="4" width="18" height="16" rx="2" fill="url(#grad2)" fill-opacity="0.9"/>
            <rect x="5" y="6" width="14" height="2" rx="1" fill="rgba(255,255,255,0.5)"/>
            <circle cx="7.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
            <circle cx="11.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
            <circle cx="15.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
            <path d="M7 15c1 0 3-.5 5-.5s4 .5 5 .5" stroke="rgba(255,255,255,0.6)" stroke-width="1.5" stroke-linecap="round" fill="none"/>
            <rect x="3" y="4" width="18" height="16" rx="2" stroke="rgba(255,255,255,0.15)" stroke-width="1" fill="none"/>
            <defs>
              <linearGradient id="grad2" x1="3" y1="4" x2="21" y2="20" gradientUnits="userSpaceOnUse">
                <stop stop-color="#0066b2"/>
                <stop offset="1" stop-color="#0078d4"/>
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
      <div class="ghost-dock__shelf">
        <div class="ghost-dock__empty">No ghost tabs</div>
      </div>
    `;const e=i=>{let d=0;i.pinned&&(d+=30),(i.restoreCount||0)>0&&(d+=20),d+=Math.min((i.totalActiveTimeMs||0)/1e3,20);const r=i.parkedAt||i.lastActiveAt||0;if(r){const h=(Date.now()-r)/36e5;d+=Math.max(0,10-h/24)}return d},c=(()=>{let i=[...f];if(g&&(i=i.filter(d=>{const r=E[d.id];return((r==null?void 0:r.aiIntent)||d.intent)===g})),m){const d=m.toLowerCase();i=i.filter(r=>{var h,y,b;return((h=r.title)==null?void 0:h.toLowerCase().includes(d))||((y=r.domain)==null?void 0:y.toLowerCase().includes(d))||((b=r.url)==null?void 0:b.toLowerCase().includes(d))})}return i.sort((d,r)=>e(r)-e(d))})().slice(0,8),a=c.filter(i=>e(i)>=15).slice(0,3).map(i=>O(i)).join(""),x=c.map(i=>N(i)).join("");return`
    <div class="ghost-dock__dock">
      <div class="ghost-dock__icon">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="3" y="4" width="18" height="16" rx="2" fill="url(#grad)" fill-opacity="0.9"/>
          <rect x="5" y="6" width="14" height="2" rx="1" fill="rgba(255,255,255,0.5)"/>
          <circle cx="7.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
          <circle cx="11.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
          <circle cx="15.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
          <path d="M7 15c1 0 3-.5 5-.5s4 .5 5 .5" stroke="rgba(255,255,255,0.6)" stroke-width="1.5" stroke-linecap="round" fill="none"/>
          <rect x="3" y="4" width="18" height="16" rx="2" stroke="rgba(255,255,255,0.15)" stroke-width="1" fill="none"/>
          <defs>
            <linearGradient id="grad" x1="3" y1="4" x2="21" y2="20" gradientUnits="userSpaceOnUse">
              <stop stop-color="#0066b2"/>
              <stop offset="1" stop-color="#0078d4"/>
            </linearGradient>
          </defs>
        </svg>
      </div>
      ${t>0?`<span class="ghost-dock__badge">${t>99?"99+":t}</span>`:""}
    </div>
    <div class="ghost-dock__shelf">
      <div class="ghost-dock__search-bar">
        <input type="text" class="ghost-dock__search-input" placeholder="Search tabs... (Press /)" value="${M(m)}" />
        <div class="ghost-dock__filter-chips">
          <span class="ghost-dock__filter-chip ${g===null?"active":""}" data-filter="all">All</span>
          <span class="ghost-dock__filter-chip ${g==="watch_later"?"active":""}" data-filter="watch_later" style="--chip-color: #E91E63">W</span>
          <span class="ghost-dock__filter-chip ${g==="learn_later"?"active":""}" data-filter="learn_later" style="--chip-color: #9C27B0">L</span>
          <span class="ghost-dock__filter-chip ${g==="read_later"?"active":""}" data-filter="read_later" style="--chip-color: #2196F3">R</span>
          <span class="ghost-dock__filter-chip ${g==="buy_later"?"active":""}" data-filter="buy_later" style="--chip-color: #4CAF50">B</span>
          <span class="ghost-dock__filter-chip ${g==="work"?"active":""}" data-filter="work" style="--chip-color: #607D8B">W</span>
        </div>
      </div>
      ${a?`
        <div class="ghost-dock__resume-bar">
          <span class="ghost-dock__resume-label">Resume</span>
          <div class="ghost-dock__resume-tabs">${a}</div>
        </div>
      `:""}
      <div class="ghost-dock__tab-rail">${x||'<div class="ghost-dock__empty">No tabs found</div>'}</div>
    </div>
  `}function N(t){const e=r=>{let h=0;r.pinned&&(h+=30),(r.restoreCount||0)>0&&(h+=20),h+=Math.min((r.totalActiveTimeMs||0)/1e3,20);const y=r.parkedAt||r.lastActiveAt||0;if(y){const b=(Date.now()-y)/36e5;h+=Math.max(0,10-b/24)}return h},s=e(t)>=15,o=e(t)>=10,c=t.faviconUrl||`https://www.google.com/s2/favicons?domain=${encodeURIComponent(t.domain)}&sz=32`,n=E[t.id],a=(n==null?void 0:n.aiIntent)||t.intent,x=C[a]||C.unknown,i=G(t.parkedAt),d=`Resume this: ${t.title||t.domain} (${i})`;return`
    <div class="ghost-dock__tab ${s?"ghost-dock__tab--resume":""} ${o&&!s?"ghost-dock__tab--priority":""}" data-id="${t.id}" title="${d}">
      <img class="ghost-dock__tab-favicon" src="${c}" alt="" />
      <span class="ghost-dock__tab-title">${M(t.title||t.domain)}</span>
      ${s?'<span class="ghost-dock__tab-resume-dot"></span>':""}
      <span class="ghost-dock__tab-indicator" style="background-color: ${x}"></span>
    </div>
  `}function O(t){const e=t.faviconUrl||`https://www.google.com/s2/favicons?domain=${encodeURIComponent(t.domain)}&sz=32`,s=G(t.parkedAt);return`
    <div class="ghost-dock__resume-tab" data-id="${t.id}" title="Resume: ${t.title||t.domain} (${s})">
      <img class="ghost-dock__resume-favicon" src="${e}" alt="" />
      <span class="ghost-dock__resume-title">${M(t.title||t.domain)}</span>
    </div>
  `}function G(t){if(!t)return"Unknown";const e=Math.floor((Date.now()-t)/1e3);return e<60?"Just now":e<3600?`${Math.floor(e/60)}m ago`:e<86400?`${Math.floor(e/3600)}h ago`:`${Math.floor(e/86400)}d ago`}function M(t){const e=document.createElement("div");return e.textContent=t,e.innerHTML}function A(t){const e=t.querySelector(".ghost-dock__dock");if(!e){console.error("GhostTabs: Dock click area not found");return}e.onclick=o=>{o.preventDefault(),o.stopPropagation(),u?(clearTimeout(u),u=null,R()):u=setTimeout(()=>{u=null,P()},400)},e.ondblclick=o=>{o.preventDefault(),o.stopPropagation(),u&&(clearTimeout(u),u=null),R()},t.querySelectorAll(".ghost-dock__tab").forEach(o=>{const c=o;c.onclick=async n=>{n.preventDefault(),n.stopPropagation();const a=c.dataset.id;a&&await I(a)},c.oncontextmenu=async n=>{n.preventDefault(),n.stopPropagation();const a=c.dataset.id;a&&await D(a)}}),t.querySelectorAll(".ghost-dock__resume-tab").forEach(o=>{const c=o;c.onclick=async n=>{n.preventDefault(),n.stopPropagation();const a=c.dataset.id;a&&await I(a)},c.oncontextmenu=async n=>{n.preventDefault(),n.stopPropagation();const a=c.dataset.id;a&&await D(a)}});const s=t.querySelector(".ghost-dock__search-input");s&&(s.oninput=()=>{m=s.value,k()},s.onkeydown=o=>{if(o.key==="Escape")m="",s.blur(),k();else if(o.key==="Enter"){const c=t.querySelector(".ghost-dock__tab");if(c){const n=c.dataset.id;n&&I(n)}}}),t.querySelectorAll(".ghost-dock__filter-chip").forEach(o=>{const c=o;c.onclick=()=>{const n=c.dataset.filter||"all";g=n==="all"?null:n,k()}}),console.log("GhostTabs: Dock events set up")}function P(){p=!p;const t=document.getElementById("ghost-dock");t&&t.classList.toggle("ghost-dock--expanded",p)}async function R(){var e;const t=await chrome.runtime.sendMessage({type:"PARK_CURRENT_TAB"});t.success&&((e=t.data)!=null&&e.skipped?T((l==null?void 0:l.toastAlreadySaved)||"Already in Ghost Shelf","warning"):T((l==null?void 0:l.toastSaved)||"Saved to GhostTabs","success"),await _()&&k())}async function I(t){(await chrome.runtime.sendMessage({type:"RESTORE_TAB",payload:{id:t}})).success?(T((l==null?void 0:l.toastRestored)||"Restored","success"),await _()&&k()):T((l==null?void 0:l.toastFailedRestore)||"Failed to restore","warning")}async function D(t){(await chrome.runtime.sendMessage({type:"DELETE_TAB",payload:{id:t}})).success&&(T((l==null?void 0:l.toastRemoved)||"Removed","info"),await _()&&k())}function k(){const t=document.getElementById("ghost-dock");t&&(t.innerHTML="",t.innerHTML=S(),A(t))}F().catch(console.error);
