const S={watch_later:"#E91E63",learn_later:"#9C27B0",read_later:"#2196F3",buy_later:"#4CAF50",compare_later:"#FF9800",work:"#607D8B",temporary:"#9E9E9E",unknown:"#795548",research:"#0ea5e9",finance:"#22c55e",social:"#8b5cf6",news:"#f97316"},C={"bottom-right":"ghost-dock--bottom-right","bottom-left":"ghost-dock--bottom-left","top-right":"ghost-dock--top-right","top-left":"ghost-dock--top-left"};let d=[],m=null,p=!1,l=null,f=[],i=null;async function E(){try{const t=await chrome.runtime.sendMessage({type:"GET_TRANSLATIONS"});t.success&&t.data&&(i=t.data)}catch{i=null}}function k(t,e="info"){const o=document.getElementById("ghost-toast");o&&o.remove();const s=document.createElement("div");s.id="ghost-toast",s.className=`ghost-toast ${e}`,s.textContent=t,document.body.appendChild(s),requestAnimationFrame(()=>s.classList.add("show")),setTimeout(()=>{s.classList.remove("show"),setTimeout(()=>s.remove(),200)},2e3)}async function L(){if(document.getElementById("ghost-dock"))return;console.log("GhostTabs: Initializing..."),await E();const t=await chrome.runtime.sendMessage({type:"GET_SETTINGS"});if(!t.success){console.error("Failed to get settings");return}if(m=t.data,console.log("GhostTabs: Settings loaded",m),!m.showGhostShelfOverlay){console.log("GhostTabs: Overlay disabled in settings");return}console.log("GhostTabs: Creating dock..."),p=!m.ghostShelfStartCollapsed,chrome.runtime.onMessage.addListener(e=>{console.log("Content script received message:",e.type),(e.type==="GHOST_TABS_UPDATED"||e.type==="REFRESH_GHOST_TABS")&&(console.log("Reloading ghost tabs..."),g().then(o=>{T().then(()=>{const s=document.getElementById("ghost-dock");s&&o&&(s.innerHTML=v(),y(s),console.log("Dock updated with",d.length,"tabs"))})}))}),await g(),await T(),B(),setInterval(async()=>{await E();const e=await g();await T();const o=document.getElementById("ghost-dock");o&&e&&(o.innerHTML=v(),y(o))},5e3)}async function g(){const t=await chrome.runtime.sendMessage({type:"GET_GHOST_TABS"});if(t.success){const e=t.data||[],o=e.map(n=>n.id).sort(),s=f.slice().sort(),c=o.length>f.length||o.some(n=>!f.includes(n)),a=f.some(n=>!o.includes(n));return c||a||o.length!==s.length?(f=e.map(n=>n.id),d=e,!0):(d=e,!1)}return!1}let b={};async function T(){try{const t=await chrome.runtime.sendMessage({type:"GET_AI_METADATA"});t.success&&(b=t.data||{})}catch{b={}}}function B(){const t=document.createElement("div");t.id="ghost-dock",t.className=`ghost-dock ${C[m.ghostShelfPosition]}`,p&&t.classList.add("ghost-dock--expanded"),t.innerHTML=v(),document.body.appendChild(t),y(t)}function v(){const t=d.length;if(d.length===0)return`
      <div class="ghost-dock__dock">
        <div class="ghost-dock__icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="4" width="18" height="16" rx="2" fill="url(#grad2)" fill-opacity="0.9"/>
            <rect x="5" y="6" width="14" height="2" rx="1" fill="rgba(255,255,255,0.5)"/>
            <circle cx="7.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
            <circle cx="11.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
            <circle cx="15.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
            <path d="M7 15c1 0 3-.5 5-.5s4 .5 5 .5" stroke="rgba(255,255,255,0.6)" stroke-width="1.5" stroke-linecap="round" fill="none"/>
            <rect x="3" y="4" width="18" height="16" rx="2" stroke="rgba(255,255,255,0.15)" stroke-width="1" fill="none"/>
            <defs>
              <linearGradient id="grad2" x1="3" y1="4" x2="21" y2="20" gradientUnits="userSpaceOnUse">
                <stop stop-color="#0066b2"/>
                <stop offset="1" stop-color="#0078d4"/>
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
      <div class="ghost-dock__shelf">
        <div class="ghost-dock__empty">No ghost tabs</div>
      </div>
    `;const e=n=>{let r=0;n.pinned&&(r+=30),(n.restoreCount||0)>0&&(r+=20),r+=Math.min((n.totalActiveTimeMs||0)/1e3,20);const _=n.parkedAt||n.lastActiveAt||0;if(_){const w=(Date.now()-_)/36e5;r+=Math.max(0,10-w/24)}return r},o=[...d].sort((n,r)=>e(r)-e(n)).slice(0,8),c=o.filter(n=>e(n)>=15).slice(0,3).map(n=>O(n)).join(""),a=o.map(n=>H(n)).join("");return`
    <div class="ghost-dock__dock">
      <div class="ghost-dock__icon">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="3" y="4" width="18" height="16" rx="2" fill="url(#grad)" fill-opacity="0.9"/>
          <rect x="5" y="6" width="14" height="2" rx="1" fill="rgba(255,255,255,0.5)"/>
          <circle cx="7.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
          <circle cx="11.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
          <circle cx="15.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
          <path d="M7 15c1 0 3-.5 5-.5s4 .5 5 .5" stroke="rgba(255,255,255,0.6)" stroke-width="1.5" stroke-linecap="round" fill="none"/>
          <rect x="3" y="4" width="18" height="16" rx="2" stroke="rgba(255,255,255,0.15)" stroke-width="1" fill="none"/>
          <defs>
            <linearGradient id="grad" x1="3" y1="4" x2="21" y2="20" gradientUnits="userSpaceOnUse">
              <stop stop-color="#0066b2"/>
              <stop offset="1" stop-color="#0078d4"/>
            </linearGradient>
          </defs>
        </svg>
      </div>
      ${t>0?`<span class="ghost-dock__badge">${t>99?"99+":t}</span>`:""}
    </div>
    <div class="ghost-dock__shelf">
      ${c?`
        <div class="ghost-dock__resume-bar">
          <span class="ghost-dock__resume-label">Resume</span>
          <div class="ghost-dock__resume-tabs">${c}</div>
        </div>
      `:""}
      <div class="ghost-dock__tab-rail">${a||'<div class="ghost-dock__empty">No tabs</div>'}</div>
    </div>
  `}function H(t){const e=h=>{let u=0;h.pinned&&(u+=30),(h.restoreCount||0)>0&&(u+=20),u+=Math.min((h.totalActiveTimeMs||0)/1e3,20);const A=h.parkedAt||h.lastActiveAt||0;if(A){const G=(Date.now()-A)/36e5;u+=Math.max(0,10-G/24)}return u},o=e(t)>=15,s=e(t)>=10,c=t.faviconUrl||`https://www.google.com/s2/favicons?domain=${encodeURIComponent(t.domain)}&sz=32`,a=b[t.id],n=(a==null?void 0:a.aiIntent)||t.intent,r=S[n]||S.unknown,_=R(t.parkedAt),w=`Resume this: ${t.title||t.domain} (${_})`;return`
    <div class="ghost-dock__tab ${o?"ghost-dock__tab--resume":""} ${s&&!o?"ghost-dock__tab--priority":""}" data-id="${t.id}" title="${w}">
      <img class="ghost-dock__tab-favicon" src="${c}" alt="" />
      <span class="ghost-dock__tab-title">${D(t.title||t.domain)}</span>
      ${o?'<span class="ghost-dock__tab-resume-dot"></span>':""}
      <span class="ghost-dock__tab-indicator" style="background-color: ${r}"></span>
    </div>
  `}function O(t){const e=t.faviconUrl||`https://www.google.com/s2/favicons?domain=${encodeURIComponent(t.domain)}&sz=32`,o=R(t.parkedAt);return`
    <div class="ghost-dock__resume-tab" data-id="${t.id}" title="Resume: ${t.title||t.domain} (${o})">
      <img class="ghost-dock__resume-favicon" src="${e}" alt="" />
      <span class="ghost-dock__resume-title">${D(t.title||t.domain)}</span>
    </div>
  `}function R(t){if(!t)return"Unknown";const e=Math.floor((Date.now()-t)/1e3);return e<60?"Just now":e<3600?`${Math.floor(e/60)}m ago`:e<86400?`${Math.floor(e/3600)}h ago`:`${Math.floor(e/86400)}d ago`}function D(t){const e=document.createElement("div");return e.textContent=t,e.innerHTML}function y(t){const e=t.querySelector(".ghost-dock__dock");if(!e){console.error("GhostTabs: Dock click area not found");return}e.onclick=o=>{o.preventDefault(),o.stopPropagation(),l?(clearTimeout(l),l=null,M()):l=setTimeout(()=>{l=null,N()},400)},e.ondblclick=o=>{o.preventDefault(),o.stopPropagation(),l&&(clearTimeout(l),l=null),M()},t.querySelectorAll(".ghost-dock__tab").forEach(o=>{const s=o;s.onclick=async c=>{c.preventDefault(),c.stopPropagation();const a=s.dataset.id;a&&await $(a)},s.oncontextmenu=async c=>{c.preventDefault(),c.stopPropagation();const a=s.dataset.id;a&&await I(a)}}),t.querySelectorAll(".ghost-dock__resume-tab").forEach(o=>{const s=o;s.onclick=async c=>{c.preventDefault(),c.stopPropagation();const a=s.dataset.id;a&&await $(a)},s.oncontextmenu=async c=>{c.preventDefault(),c.stopPropagation();const a=s.dataset.id;a&&await I(a)}}),console.log("GhostTabs: Dock events set up")}function N(){p=!p;const t=document.getElementById("ghost-dock");t&&t.classList.toggle("ghost-dock--expanded",p)}async function M(){var e;const t=await chrome.runtime.sendMessage({type:"PARK_CURRENT_TAB"});t.success&&((e=t.data)!=null&&e.skipped?k((i==null?void 0:i.toastAlreadySaved)||"Already in Ghost Shelf","warning"):k((i==null?void 0:i.toastSaved)||"Saved to GhostTabs","success"),await g()&&x())}async function $(t){(await chrome.runtime.sendMessage({type:"RESTORE_TAB",payload:{id:t}})).success?(k((i==null?void 0:i.toastRestored)||"Restored","success"),await g()&&x()):k((i==null?void 0:i.toastFailedRestore)||"Failed to restore","warning")}async function I(t){(await chrome.runtime.sendMessage({type:"DELETE_TAB",payload:{id:t}})).success&&(k((i==null?void 0:i.toastRemoved)||"Removed","info"),await g()&&x())}function x(){const t=document.getElementById("ghost-dock");t&&(t.innerHTML="",t.innerHTML=v(),y(t))}L().catch(console.error);
