const x={watch_later:"#E91E63",learn_later:"#9C27B0",read_later:"#2196F3",buy_later:"#4CAF50",compare_later:"#FF9800",work:"#607D8B",temporary:"#9E9E9E",unknown:"#795548",research:"#0ea5e9",finance:"#22c55e",social:"#8b5cf6",news:"#f97316"},H={"bottom-right":"ghost-dock--bottom-right","bottom-left":"ghost-dock--bottom-left","top-right":"ghost-dock--top-right","top-left":"ghost-dock--top-left"};let u=[],m=null,p=!1,h=null,r=null;function T(){return`ghostDock_scroll_${window.location.href}`}async function v(t){try{await chrome.storage.local.set({[T()]:t})}catch{}}async function P(){try{return(await chrome.storage.local.get(T()))[T()]||0}catch{return 0}}async function q(){try{const t=await chrome.runtime.sendMessage({type:"GET_TRANSLATIONS"});t.success&&t.data&&(r=t.data)}catch{r=null}}function _(t,e="info"){const n=document.getElementById("ghost-toast");n&&n.remove();const c=document.createElement("div");c.id="ghost-toast",c.className=`ghost-toast ${e}`,c.textContent=t,document.body.appendChild(c),requestAnimationFrame(()=>c.classList.add("show")),setTimeout(()=>{c.classList.remove("show"),setTimeout(()=>c.remove(),200)},2e3)}async function N(){if(document.getElementById("ghost-dock"))return;console.log("GhostTabs: Initializing..."),await q();const t=await chrome.runtime.sendMessage({type:"GET_SETTINGS"});if(!t.success){console.error("Failed to get settings");return}if(m=t.data,console.log("GhostTabs: Settings loaded",m),!m.showGhostShelfOverlay){console.log("GhostTabs: Overlay disabled in settings");return}console.log("GhostTabs: Creating dock..."),p=!m.ghostShelfStartCollapsed,chrome.runtime.onMessage.addListener(e=>{console.log("Content script received message:",e.type),(e.type==="GHOST_TABS_UPDATED"||e.type==="REFRESH_GHOST_TABS")&&(console.log("Reloading ghost tabs..."),k().then(async()=>{await A(),w(),console.log("Dock updated with",u.length,"tabs")}))}),await k(),await A(),O()}async function k(){const t=await chrome.runtime.sendMessage({type:"GET_GHOST_TABS"});t.success&&(u=t.data||[])}let S={};async function A(){try{const t=await chrome.runtime.sendMessage({type:"GET_AI_METADATA"});t.success&&(S=t.data||{})}catch{S={}}}function O(){const t=document.createElement("div");t.id="ghost-dock",t.className=`ghost-dock ${H[m.ghostShelfPosition]}`,p&&t.classList.add("ghost-dock--expanded"),t.innerHTML=C(),document.body.appendChild(t),y(t)}function C(){const t=u.length;if(u.length===0)return`
      <div class="ghost-dock__dock">
        <div class="ghost-dock__icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="4" width="18" height="16" rx="2" fill="url(#grad2)" fill-opacity="0.9"/>
            <rect x="5" y="6" width="14" height="2" rx="1" fill="rgba(255,255,255,0.5)"/>
            <circle cx="7.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
            <circle cx="11.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
            <circle cx="15.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
            <path d="M7 15c1 0 3-.5 5-.5s4 .5 5 .5" stroke="rgba(255,255,255,0.6)" stroke-width="1.5" stroke-linecap="round" fill="none"/>
            <rect x="3" y="4" width="18" height="16" rx="2" stroke="rgba(255,255,255,0.15)" stroke-width="1" fill="none"/>
            <defs>
              <linearGradient id="grad2" x1="3" y1="4" x2="21" y2="20" gradientUnits="userSpaceOnUse">
                <stop stop-color="#0066b2"/>
                <stop offset="1" stop-color="#0078d4"/>
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
      <div class="ghost-dock__shelf">
        <div class="ghost-dock__empty">No ghost tabs</div>
      </div>
    `;const e=o=>{let i=0;o.pinned&&(i+=30),(o.restoreCount||0)>0&&(i+=20),i+=Math.min((o.totalActiveTimeMs||0)/1e3,20);const l=o.parkedAt||o.lastActiveAt||0;if(l){const d=(Date.now()-l)/36e5;i+=Math.max(0,10-d/24)}return i},n=[...u].sort((o,i)=>e(i)-e(o)),a=n.filter(o=>e(o)>=15).slice(0,3).map(o=>I(o)).join(""),s=n.map(o=>L(o)).join("");return`
    <div class="ghost-dock__dock">
      <div class="ghost-dock__icon">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="3" y="4" width="18" height="16" rx="2" fill="url(#grad)" fill-opacity="0.9"/>
          <rect x="5" y="6" width="14" height="2" rx="1" fill="rgba(255,255,255,0.5)"/>
          <circle cx="7.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
          <circle cx="11.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
          <circle cx="15.5" cy="11.5" r="1.5" fill="rgba(255,255,255,0.6)"/>
          <path d="M7 15c1 0 3-.5 5-.5s4 .5 5 .5" stroke="rgba(255,255,255,0.6)" stroke-width="1.5" stroke-linecap="round" fill="none"/>
          <rect x="3" y="4" width="18" height="16" rx="2" stroke="rgba(255,255,255,0.15)" stroke-width="1" fill="none"/>
          <defs>
            <linearGradient id="grad" x1="3" y1="4" x2="21" y2="20" gradientUnits="userSpaceOnUse">
              <stop stop-color="#0066b2"/>
              <stop offset="1" stop-color="#0078d4"/>
            </linearGradient>
          </defs>
        </svg>
      </div>
      ${t>0?`<span class="ghost-dock__badge">${t>99?"99+":t}</span>`:""}
    </div>
    <div class="ghost-dock__shelf">
      ${a?`
        <div class="ghost-dock__resume-bar">
          <span class="ghost-dock__resume-label">Resume</span>
          <div class="ghost-dock__resume-tabs">${a}</div>
        </div>
      `:""}
      <div class="ghost-dock__tab-rail">${s||'<div class="ghost-dock__empty">No tabs</div>'}</div>
    </div>
  `}function L(t){const e=g=>{let f=0;g.pinned&&(f+=30),(g.restoreCount||0)>0&&(f+=20),f+=Math.min((g.totalActiveTimeMs||0)/1e3,20);const b=g.parkedAt||g.lastActiveAt||0;if(b){const B=(Date.now()-b)/36e5;f+=Math.max(0,10-B/24)}return f},n=e(t)>=15,c=e(t)>=10,a=t.faviconUrl||`https://www.google.com/s2/favicons?domain=${encodeURIComponent(t.domain)}&sz=32`,s=S[t.id],o=(s==null?void 0:s.aiIntent)||t.intent,i=x[o]||x.unknown,l=R(t.parkedAt),d=`Resume this: ${t.title||t.domain} (${l})`;return`
    <div class="ghost-dock__tab ${n?"ghost-dock__tab--resume":""} ${c&&!n?"ghost-dock__tab--priority":""}" data-id="${t.id}" title="${d}">
      <img class="ghost-dock__tab-favicon" src="${a}" alt="" />
      <span class="ghost-dock__tab-title">${G(t.title||t.domain)}</span>
      ${n?'<span class="ghost-dock__tab-resume-dot"></span>':""}
      <span class="ghost-dock__tab-indicator" style="background-color: ${i}"></span>
    </div>
  `}function I(t){const e=t.faviconUrl||`https://www.google.com/s2/favicons?domain=${encodeURIComponent(t.domain)}&sz=32`,n=R(t.parkedAt);return`
    <div class="ghost-dock__resume-tab" data-id="${t.id}" title="Resume: ${t.title||t.domain} (${n})">
      <img class="ghost-dock__resume-favicon" src="${e}" alt="" />
      <span class="ghost-dock__resume-title">${G(t.title||t.domain)}</span>
    </div>
  `}function R(t){if(!t)return"Unknown";const e=Math.floor((Date.now()-t)/1e3);return e<60?"Just now":e<3600?`${Math.floor(e/60)}m ago`:e<86400?`${Math.floor(e/3600)}h ago`:`${Math.floor(e/86400)}d ago`}function G(t){const e=document.createElement("div");return e.textContent=t,e.innerHTML}function y(t){const e=t.querySelector(".ghost-dock__dock");if(!e){console.error("GhostTabs: Dock click area not found");return}const n=t.querySelector(".ghost-dock__tab-rail");n&&(n.onscroll=()=>{v(n.scrollLeft)}),e.onclick=c=>{c.preventDefault(),c.stopPropagation(),h?(clearTimeout(h),h=null,E()):h=setTimeout(()=>{h=null,U()},400)},e.ondblclick=c=>{c.preventDefault(),c.stopPropagation(),h&&(clearTimeout(h),h=null),E()},t.querySelectorAll(".ghost-dock__tab").forEach(c=>{const a=c;a.onclick=async s=>{s.preventDefault(),s.stopPropagation();const o=a.dataset.id;o&&await M(o)},a.oncontextmenu=async s=>{s.preventDefault(),s.stopPropagation();const o=a.dataset.id;o&&await $(o)}}),t.querySelectorAll(".ghost-dock__resume-tab").forEach(c=>{const a=c;a.onclick=async s=>{s.preventDefault(),s.stopPropagation();const o=a.dataset.id;o&&await M(o)},a.oncontextmenu=async s=>{s.preventDefault(),s.stopPropagation();const o=a.dataset.id;o&&await $(o)}}),console.log("GhostTabs: Dock events set up")}function U(){p=!p;const t=document.getElementById("ghost-dock");t&&t.classList.toggle("ghost-dock--expanded",p)}async function E(){var a;const t=document.getElementById("ghost-dock"),e=t==null?void 0:t.querySelector(".ghost-dock__tab-rail"),n=(e==null?void 0:e.scrollLeft)??0;await v(n);const c=await chrome.runtime.sendMessage({type:"PARK_CURRENT_TAB"});c.success&&((a=c.data)!=null&&a.skipped?_((r==null?void 0:r.toastAlreadySaved)||"Already in Ghost Shelf","warning"):_((r==null?void 0:r.toastSaved)||"Saved to GhostTabs","success"),await k(),w())}async function M(t){const e=document.getElementById("ghost-dock"),n=e==null?void 0:e.querySelector(".ghost-dock__tab-rail"),c=(n==null?void 0:n.scrollLeft)??0;await v(c),(await chrome.runtime.sendMessage({type:"RESTORE_TAB",payload:{id:t}})).success?(_((r==null?void 0:r.toastRestored)||"Restored","success"),await k(),w()):_((r==null?void 0:r.toastFailedRestore)||"Failed to restore","warning")}async function $(t){const e=document.getElementById("ghost-dock"),n=e==null?void 0:e.querySelector(".ghost-dock__tab-rail"),c=(n==null?void 0:n.scrollLeft)??0;await v(c),(await chrome.runtime.sendMessage({type:"DELETE_TAB",payload:{id:t}})).success&&(_((r==null?void 0:r.toastRemoved)||"Removed","info"),await k(),w())}function w(){const t=document.getElementById("ghost-dock");if(t){const e=t.querySelector(".ghost-dock__dock"),n=t.querySelector(".ghost-dock__badge"),c=(n==null?void 0:n.textContent)??"",a=u.length,s=a>0?a>99?"99+":String(a):"",o=async()=>{const i=t==null?void 0:t.querySelector(".ghost-dock__tab-rail");if(i){const l=await P(),d=i.scrollWidth-i.clientWidth,g=Math.min(l,Math.max(0,d));requestAnimationFrame(()=>{i.scrollLeft=g})}};if(c===s&&e){const i=D(),l=t.querySelector(".ghost-dock__shelf");l&&(l.innerHTML=i,y(t),o())}else if(e){const i=D(),l=t.querySelector(".ghost-dock__shelf");if(l&&(l.innerHTML=i),n)n.textContent=s;else if(s){const d=document.createElement("span");d.className="ghost-dock__badge",d.textContent=s,e.appendChild(d)}y(t),o()}else t.innerHTML=C(),y(t)}}function D(){const t=s=>{let o=0;s.pinned&&(o+=30),(s.restoreCount||0)>0&&(o+=20),o+=Math.min((s.totalActiveTimeMs||0)/1e3,20);const i=s.parkedAt||s.lastActiveAt||0;if(i){const l=(Date.now()-i)/36e5;o+=Math.max(0,10-l/24)}return o},e=[...u].sort((s,o)=>t(o)-t(s)),c=e.filter(s=>t(s)>=15).slice(0,3).map(s=>I(s)).join(""),a=e.map(s=>L(s)).join("");return`
    ${c?`
      <div class="ghost-dock__resume-bar">
        <span class="ghost-dock__resume-label">Resume</span>
        <div class="ghost-dock__resume-tabs">${c}</div>
      </div>
    `:""}
    <div class="ghost-dock__tab-rail">${a||'<div class="ghost-dock__empty">No tabs</div>'}</div>
  `}N().catch(console.error);
